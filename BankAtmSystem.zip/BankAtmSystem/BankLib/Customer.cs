﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    public class Customer
    {
        public string Name { get; set; }
        public string NRIC { get; set; }
        public string Acc_no { get; set; }
        public string Cardno { get; set; }
        public string Pinno { get; set; }
        public string Acc_status { get; set; }
        public int Starting_Balance { get; set; }
        public int CustomerID { get; set; }
        public long Age { get; set; }
        public static int increasedid = 1;

        public Customer()
        {
            CustomerID = increasedid++;
            Acc_status = "Active";
        }
    }
}
