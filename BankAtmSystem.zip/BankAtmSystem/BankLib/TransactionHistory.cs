﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    public class TransactionHistory
    {
        public int ID { get; set; }
        public string TransactionUserAccount { get; set; }
        public float Transaction_debitrekod { get; set; }
        public float Transaction_creditrekod { get; set; }
        public string TransactionType { get; set; }
        public DateTime TransactionTime { get; set; }
        public static int increaseID = 1;

        public TransactionHistory()
        {
            ID = increaseID++;
        }
    }
}
