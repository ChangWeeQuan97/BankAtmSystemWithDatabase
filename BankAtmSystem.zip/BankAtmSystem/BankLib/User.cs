﻿using ConsoleTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLib
{
    public class User
    {
        public string Cardno { get; set; }
        public string Pinno { get; set; }
        public string Name { get; set; }
        public float balance { get; set; }
        public string Acc_no { get; set; }
        public bool cek { get; set; }
        public float withdraw_limit { get; set; }
        public int Login_Attempt { get; set; }


        public User()
        {
            Login_Attempt = 3;
            balance = 10000;
            withdraw_limit = 9980;
        }
        public void table(IEnumerable<TransactionHistory> q)
        {
            Console.WriteLine($"Hi, {Name}");
            Console.WriteLine($"Current Balance is : { Math.Round((float)balance, 2)}");
            var table = new ConsoleTable("Transaction Date", "Account", "Transaction Type", " Debit", " Credit");
            foreach (var item in q)
            {
                if (item.TransactionUserAccount == Acc_no && table.Rows.Count<5)
                {
                    table.AddRow(item.TransactionTime, item.TransactionUserAccount, item.TransactionType, item.Transaction_debitrekod, item.Transaction_creditrekod);
                }
            }
            table.Options.EnableCount = false;
            table.Write();
            other_method.PrintforUser();
        }
        public void cek_Balance()
        {
            other_method.yellow_head("                    Balance Inquiry ", ConsoleColor.Yellow);
            Console.WriteLine($"\nHi, {Name}");
            Console.WriteLine("Current Balance is RM " + Math.Round((float)balance, 2));
            other_method.PrintforUser();
        }
        public void Login_Successful()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("<-Login Successful->");
            Login_Attempt = 3;
        }
        public void Menu()
        {
            other_method.yellow_head("       Welcome to GE LEGACY BANK ATM SERVICE ", ConsoleColor.Yellow);
            Console.WriteLine($"Hi, {Name}");
            Console.WriteLine("1. Balance Inquiry");
            Console.WriteLine("2. Withdrawal ");
            Console.WriteLine("3. Fast Cash Withdrawal ");
            Console.WriteLine("4. Deposit ");
            Console.WriteLine("5. Change Pin ");
            Console.WriteLine("6. Third Party Transfer ");
            Console.WriteLine("7. Transaction History ");
            Console.WriteLine("8. Bank Account Details ");
            Console.WriteLine("9. Logout ");
            Console.WriteLine("10. Exit ");
            Console.Write("Enter Your Option:");
        }
        public void Insufficient_Balance()
        {
            Console.WriteLine($"\nYour available balance is RM { Math.Round((float)balance, 2)}.");
            other_method.color_text("Sorry! Insufficient Balance.", ConsoleColor.Red);
        }
        public void Require_Balance(string text, float f)
        {
            Console.WriteLine($"\nCan't {text}  {f} , your available balance is RM { Math.Round((float)balance, 2)}.");
            other_method.color_text("Minimum required balance is RM20. ", ConsoleColor.Red);
        }
        public void Enter_New_Pin()
        {
            Console.Clear();
            Console.WriteLine("Enter Your New Pin No: ");
            string newpin = Console.ReadLine();
            cek = int.TryParse(newpin, out int new_pin) && newpin.Length == 6;

            if (cek == false)
            {
                other_method.color_text("\nEnter 6 Digit No.", ConsoleColor.Blue);
            }
            else if (new_pin < 0)
            {
                other_method.color_text("\nCan't insert negative number. ", ConsoleColor.Red);
            }
            else if (newpin == Pinno)
            {
                other_method.color_text("\nCan't change to the old pin no.  ", ConsoleColor.Red);
            }
            else
            {
                Pinno = newpin;
                other_method.color_text("\nPin No change successful", ConsoleColor.Green);
            }
        }
        public void Balance_After_Withdraw(float withdraw, List<TransactionHistory> q)
        {
            balance = other_method.CalculateMinus_Balance(this, withdraw); withdraw_limit = other_method.CalculateMinus_WithdrawLimit(this, withdraw);
            q.Add(new TransactionHistory {TransactionUserAccount = Acc_no, Transaction_debitrekod = withdraw, Transaction_creditrekod = 0, TransactionTime = DateTime.Now, TransactionType = "WithDraw" });
            other_method.AfterProcess_withdraw();
            Console.WriteLine("After withdraw, current Balance is RM " + Math.Round((float)balance, 2));
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void Balance_After_FastWithdraw(float withdraw, string s, List<TransactionHistory> q)
        {
            balance = other_method.CalculateMinus_Balance(this, withdraw); withdraw_limit = other_method.CalculateMinus_WithdrawLimit(this, withdraw);
            q.Add(new TransactionHistory {TransactionUserAccount = Acc_no, Transaction_debitrekod = withdraw, Transaction_creditrekod = 0, TransactionTime = DateTime.Now, TransactionType = s });
            other_method.AfterProcess_fastwithdraw();
            Console.WriteLine($"After withdraw {withdraw}, current Balance is RM{  Math.Round((float)balance, 2)}");
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void Balance_After_Deposit(int deposit, List<TransactionHistory> q)
        {
            balance = other_method.CalculatePlus_Balance(this, deposit); withdraw_limit = other_method.CalculatePlus_WithdrawLimit(this, deposit);
            q.Add(new TransactionHistory {TransactionUserAccount = Acc_no, Transaction_debitrekod = 0, Transaction_creditrekod = deposit, TransactionTime = DateTime.Now, TransactionType = "Deposit" });
            other_method.AfterProcess();
            other_method.Count_Notes(deposit);
            Console.WriteLine("Current Balance is RM " + Math.Round((float)balance, 2));
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void Balance_After_Transfer(User r, float transfer, List<TransactionHistory> q)
        {
            balance = other_method.CalculateMinus_Balance(this, (float)Math.Round(transfer, 2)); withdraw_limit = other_method.CalculateMinus_WithdrawLimit(this, (float)Math.Round(transfer, 2));
            r.balance = other_method.CalculatePlus_Balance(r, (float)Math.Round(transfer, 2)); r.withdraw_limit = other_method.CalculatePlus_WithdrawLimit(r, (float)Math.Round(transfer, 2));
            q.Add(new TransactionHistory { TransactionUserAccount = Acc_no, Transaction_debitrekod = (float)Math.Round(transfer, 2), Transaction_creditrekod = 0, TransactionType = "Transfer to " + r.Acc_no, TransactionTime = DateTime.Now });
            q.Add(new TransactionHistory { TransactionUserAccount = r.Acc_no, Transaction_debitrekod = 0, Transaction_creditrekod = (float)Math.Round(transfer, 2), TransactionType = "Receive from " + Acc_no, TransactionTime = DateTime.Now });
            other_method.AfterProcess();
            Console.WriteLine("Current Balance is RM " + Math.Round((float)balance, 2));
            other_method.yes_no("\nDo you need any receipt?");
        }
        public void fastwithdraw(float num, List<TransactionHistory> q)
        {
            if (num > balance)
            {
                Insufficient_Balance();
            }
            else
            {
                if (num > withdraw_limit)
                {
                    Require_Balance("withdraw", num);
                }
                else
                {
                    Balance_After_FastWithdraw(num, "Fast Withdrawal",  q);

                    if (Console.ReadLine() == "1")
                    {
                        other_method.Print_Receipt();
                    }
                    else
                    {
                        Console.Clear();
                    }
                }
            }
        }
        public void Account_Detail_Table()
        {
            int[] num = { 1, 2, 3, 4, 5 };
            string[] particular = { "Name : " + Name, "Account No : " + Acc_no, "Card No : " + Cardno, "Pin No : ******", "Account Status : Active" };
            other_method.yellow_head("                 Bank Account Detail ", ConsoleColor.Yellow);
            var table = new ConsoleTable("No", "Your Particulars");
            for (int i = 0; i < 5; i++)
            {
                table.AddRow(num[i], particular[i]);
            }
            table.Options.EnableCount = false;
            table.Write();
            other_method.PrintforUser();
        }
    }
}
