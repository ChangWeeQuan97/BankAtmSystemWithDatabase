﻿using ConsoleTables;
using PanoramicData.ConsoleExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BankLib
{
    public class Bank
    {
        public string BankAdminName { get; set; }
        public string Password { get; set; }

        public Bank()
        {
            BankAdminName = "qwe";
            Password = "asd123";
        }
        public void AddAccount( List<Customer> listofcustomer)
        {
            other_method.yellow_head("                      Add Account ", ConsoleColor.Yellow);
            Console.WriteLine("Enter Customer Full Name :");
            string Name = Console.ReadLine();
            bool check = new Regex("^^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)").IsMatch(Name);
            while (!check)
            {
                other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                Console.Write("Please Enter a valid name: ");
                check = new Regex("^^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)").IsMatch(Name = Console.ReadLine()); ;
            }
            Console.WriteLine("\nEnter Customer NRIC :");
            string nric = Console.ReadLine();
            check = new Regex("^\\d{6}\\-\\d{2}\\-\\d{4}$").IsMatch(nric);
            while (!check || listofcustomer.Any(x => x.NRIC == nric))
            {
                other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                Console.Write("Please enter correct NRIC format: ");
                check = new Regex("^\\d{6}\\-\\d{2}\\-\\d{4}$").IsMatch(nric = Console.ReadLine());
            }
            string acc_no = other_method.RandomAccountNumber(6);
            while (listofcustomer.Any(x => x.Acc_no == acc_no))
            {
                acc_no = other_method.RandomAccountNumber(6);
            }
            Console.WriteLine("\nEnter Bank Account Starting Balance :");
            check = int.TryParse(Console.ReadLine(), out int starting_balance) && starting_balance >= 250;
            while (!check)
            {
                other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                Console.Write("Please enter a valid amount: ");
                check = int.TryParse(Console.ReadLine(), out starting_balance) && starting_balance >= 250;
            }
            string cardno = other_method.RandomNumber(16);
            while (listofcustomer.Any(x => x.Cardno == cardno))
            {
                cardno = other_method.RandomNumber(16);
            }
            Console.WriteLine("\nEnter Pin No :");
            string pinno = ConsolePlus.ReadPassword();
            check = int.TryParse(pinno, out int Pinno) && pinno.Length == 6;
            while (!check)
            {
                other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                Console.Write("Please enter 6 digit number: ");
                check = int.TryParse(pinno = ConsolePlus.ReadPassword(), out Pinno) && pinno.Length == 6;
            }
            Console.WriteLine("\nRe-enter Pin No :");
            string repinno = ConsolePlus.ReadPassword();
            check = int.TryParse(repinno, out Pinno) && pinno.Length == 6;
            while (!check || repinno != pinno)
            {
                other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                Console.Write("Please enter 6 digit number: ");
                check = int.TryParse(repinno = ConsolePlus.ReadPassword(), out Pinno) && pinno.Length == 6;
            }
            listofcustomer.Add(new Customer { Name = Name, NRIC = nric, Age = CountAge(nric), Acc_no = acc_no, Starting_Balance = starting_balance, Cardno = cardno, Pinno = repinno });
            other_method.ColorText("\nBank Account added successful", ConsoleColor.Green);
            table(listofcustomer);
            other_method.PrintforUser();
        }
        public void ManageAccount( List<Customer> listofcustomer)
        {
            if (listofcustomer.Count == 0)
            {
                other_method.ColorText("No record", ConsoleColor.Blue);
                other_method.PrintforUser();
                return;
            }
            other_method.yellow_head("                    Manage Account ", ConsoleColor.Yellow);
            table(listofcustomer);
            Console.WriteLine("Enter CustomerID : ");
            bool cek = int.TryParse(Console.ReadLine(), out int CustomerID);
            var FindID = listofcustomer.Where(e => e.CustomerID == CustomerID).SingleOrDefault();
            
            while (FindID == null || !cek)
            {
                other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                Console.Write("Please enter number: ");
                cek = int.TryParse(Console.ReadLine(), out CustomerID);
                FindID = listofcustomer.Where(e => e.CustomerID == CustomerID).SingleOrDefault();
            }
            other_method.ColorText("\nCustomer Details", ConsoleColor.Yellow);
            Console.WriteLine("Full Name: " + FindID.Name);
            Console.WriteLine("NRIC: " + FindID.NRIC);
            Console.WriteLine("Age: " + FindID.Age);
            Console.WriteLine("Account No: " + FindID.Acc_no);
            Console.WriteLine("Starting Balance: " + FindID.Starting_Balance);
            Console.WriteLine("Card No: " + FindID.Cardno);
            Console.WriteLine("Pin No: ******");
            Console.WriteLine("Account Status: " + FindID.Acc_status);
            string edit_delete = string.Empty;
            do
            {
                Console.WriteLine("\nEdit(E) or Delete(D) ?");
                edit_delete = Console.ReadLine().ToUpper();
            }
            while (edit_delete != "E" && edit_delete != "D");
            if (edit_delete == "D")
            {
                string yes_no = string.Empty;
                do
                {
                    Console.WriteLine("\nAre you sure ? Yes(Y) or No(N) ?");
                    yes_no = Console.ReadLine().ToUpper();
                }
                while (yes_no != "Y" && yes_no != "N");
                if (yes_no == "Y")
                {
                    listofcustomer.Remove(FindID);
                    other_method.ColorText("\nBank Account remove successful", ConsoleColor.Green);
                    table(listofcustomer);
                    other_method.PrintforUser();
                }
                Console.Clear();
            }
            else
            {
                Console.WriteLine("\n1. Update Name");
                Console.WriteLine("2. Update NRIC");
                Console.WriteLine("3. Update Card No");
                Console.WriteLine("4. Update Account Status");
                Console.WriteLine("5. Update all the customer detail");
                Console.WriteLine("Enter Your Option : ");
                string edit = Console.ReadLine();
                Console.Clear();
                if (edit == "1")
                {
                    Console.WriteLine("Enter Customer Full Name");
                    string name = Console.ReadLine();
                    bool check = new Regex("^^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)").IsMatch(name);
                    while (!check)
                    {
                        other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                        Console.Write("Please Enter a valid name: ");
                        check = new Regex("^^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)").IsMatch(name = Console.ReadLine());
                    }
                    Console.Write("\nPlease enter Yes(Y) or No(N): ");
                    string yes_no = Console.ReadLine().ToUpper();
                    if (yes_no == "Y")
                    {
                        FindID.Name = name;
                        other_method.ColorText("\nBank Account update successful", ConsoleColor.Green);
                        table(listofcustomer);
                        other_method.PrintforUser();
                    }
                    Console.Clear();
                }
                else if (edit == "2")
                {
                    Console.WriteLine("Enter NRIC :");
                    string nric = Console.ReadLine();
                    bool check = new Regex("^\\d{6}\\-\\d{2}\\-\\d{4}$").IsMatch(nric);
                    while (!check  || listofcustomer.Any(x => x.NRIC == nric))
                    {
                        other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                        Console.Write("Please enter correct NRIC format: ");
                        check = new Regex("^\\d{6}\\-\\d{2}\\-\\d{4}$").IsMatch(nric = Console.ReadLine());
                    }
                    Console.Write("\nPlease enter Yes(Y) or No(N): ");
                    string yes_no = Console.ReadLine().ToUpper();
                    if (yes_no == "Y")
                    {
                        FindID.NRIC = nric; FindID.Age = CountAge(nric);
                        other_method.ColorText("Bank Account update successful", ConsoleColor.Green);
                        table(listofcustomer);
                        other_method.PrintforUser();
                    }
                    Console.Clear();
                }
                else if (edit == "3")
                {
                    string cardno = other_method.RandomNumber(16);
                    while (listofcustomer.Any(x => x.Cardno == cardno))
                    {
                        cardno = other_method.RandomNumber(16);
                    }
                    FindID.Cardno = cardno;
                    other_method.ColorText("Bank Account update successful", ConsoleColor.Green);
                    table(listofcustomer);
                    other_method.PrintforUser();
                }
                else if (edit == "4")
                {
                    if (FindID.Acc_status == "Active")
                    {
                        FindID.Acc_status = "Locked";
                    }
                    else
                    {
                        FindID.Acc_status = "Active";
                    }
                    other_method.ColorText("Bank Account update successful", ConsoleColor.Green);
                    table(listofcustomer);
                    other_method.PrintforUser();
                }
                else if (edit == "5")
                {
                    Console.WriteLine("Enter Customer Full Name :");
                    string Name = Console.ReadLine();
                    bool check = new Regex("^^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)").IsMatch(Name);
                    while (!check)
                    {
                        other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                        Console.Write("Please Enter a valid name: ");
                        check = new Regex("^^([a-zA-Z]{2,}\\s[a-zA-Z]{1,}'?-?[a-zA-Z]{2,}\\s?([a-zA-Z]{1,})?)").IsMatch(Name = Console.ReadLine());
                    }
                    Console.WriteLine("\nEnter Customer NRIC :");
                    string nric = Console.ReadLine();
                    check = new Regex("^\\d{6}\\-\\d{2}\\-\\d{4}$").IsMatch(nric);
                    while (!check  || listofcustomer.Any(x => x.NRIC == nric))
                    {
                        other_method.ColorText("\nInvalid Input. Try again...", ConsoleColor.Red);
                        Console.Write("Please enter correct NRIC format: ");
                        check = new Regex("^\\d{6}\\-\\d{2}\\-\\d{4}$").IsMatch(nric = Console.ReadLine());
                    }
                    string cardno = other_method.RandomNumber(16);
                    while (listofcustomer.Any(x => x.Cardno == cardno))
                    {
                        cardno = other_method.RandomNumber(16);
                    }
                    Console.Write("\nPlease enter Yes(Y) or No(N): ");
                    string yes_no = Console.ReadLine().ToUpper();
                    if (yes_no == "Y")
                    {
                        FindID.Name = Name; FindID.NRIC = nric; FindID.Age = CountAge(nric); FindID.Cardno = cardno;
                        other_method.ColorText("\nBank Account update successful", ConsoleColor.Green);
                        table(listofcustomer);
                        other_method.PrintforUser();
                    }
                    Console.Clear();
                }
                else
                {
                    other_method.ColorText("Invalid Option", ConsoleColor.Red);
                    other_method.PrintforUser();
                }
            }
        }
        public void PrintList(List<Customer> listofcustomer)
        {
            if (listofcustomer.Count == 0)
            {
                other_method.ColorText("No record", ConsoleColor.Blue);
                other_method.PrintforUser();
                return;
            }
            Console.WriteLine("1. Order by Ascending (Name)");
            Console.WriteLine("2. Order by Descending (Name)");
            Console.WriteLine("3. Order by Ascending (Age)");
            Console.WriteLine("4. Order by Descending (Age)");
            Console.WriteLine("5. Order by Ascending (Account No)");
            Console.WriteLine("6. Order by Descending (Account No)");
            Console.WriteLine("Enter Your Option : ");
            string order = Console.ReadLine();
            if (order == "1")
            {
                table(listofcustomer.OrderBy(s => s.Name));
            }
            else if (order == "2")
            {
                table(listofcustomer.OrderByDescending(s => s.Name));
            }
            else if (order == "3")
            {
                table(listofcustomer.OrderBy(s => s.Age));
            }
            else if (order == "4")
            {
                table(listofcustomer.OrderByDescending(s => s.Age));
            }
            else if (order == "5")
            {
                table(listofcustomer.OrderBy(s => s.Acc_no));
            }
            else if (order == "6")
            {
                table(listofcustomer.OrderByDescending(s => s.Acc_no));
            }
            else
            {
                other_method.ColorText("Invalid Option", ConsoleColor.Red);
            }
            other_method.PrintforUser();
        }
        public void table(IEnumerable<Customer> q)
        {
            var table = new ConsoleTable("ID", "Full Name", "NRIC", "Age", "Account No", "Card No", "Account Status");

            foreach (Customer customer in q)
            {
                table.AddRow(customer.CustomerID, customer.Name, customer.NRIC, customer.Age, customer.Acc_no, customer.Cardno, customer.Acc_status);
            }
            table.Write();
        }
        public static int CountAge(string s)
        {
            int age = Convert.ToInt32(s.Substring(0, 2));
            if (age >= Convert.ToInt32(DateTime.Now.Year.ToString().Substring(2)) + 100 - 111 && age <= 99)
            {
                age = (Convert.ToInt32(DateTime.Now.Year.ToString().Substring(2)) + 100) - age;
            }
            else
            {
                age = Convert.ToInt32(DateTime.Now.Year.ToString().Substring(2)) - age;
            }
            return age;
        }
    }
}
