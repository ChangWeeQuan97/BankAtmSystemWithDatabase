﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BankLib
{
    public class other_method
    {
        public static void Thank_you()
        {
            Console.Write("Hope you enjoy our service, ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Thank You !\n");
            Console.ResetColor();
            PrintforUser();
        }
        public static void PrintforUser()
        {
            Console.Write("Press Y or any key to continue");
            Console.ReadKey();
            Console.Clear();
        }
        public static void Min_amount()=> color_text("\nSystem can't accept this amount", ConsoleColor.Red);
        public static void AfterProcess_withdraw()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nProcessing Successful");
            Thread.Sleep(1000);
            Console.ResetColor();
            Console.WriteLine("Please take your cash. ");
        }
        public static void AfterProcess_fastwithdraw()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Processing Successful");
            Thread.Sleep(1000);
            Console.ResetColor();
            Console.WriteLine("Please take your cash. ");
        }
        public static void AfterProcess()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nProcessing Successful");
            Thread.Sleep(1000);
            Console.ResetColor();
        }
        public static void yes_no(string s)
        {
            Console.WriteLine(s);
            Console.WriteLine("1. Yes\t2. No");
            Console.Write("Enter Your Option: ");
        }
        public static void Print_Receipt()
        {
            Console.Clear();
            Console.WriteLine("Your receipt is printing succesfully, please take your receipt. ");
            PrintforUser();
        }
        public static void yellow_head(string s, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.WriteLine(s);
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.ResetColor();
        }
        public static void yellow_text(string s, string t)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.WriteLine(s);
            Console.WriteLine("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            Console.ResetColor();
            Console.WriteLine(t);
        }
        
        public static void color_text(string s, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(s);
            Console.ResetColor();
            PrintforUser();
        }
        public static void ColorText(string s, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(s);
            Console.ResetColor();
        }
        public static void Fast_Cash()
        {
            yellow_head("                 Fast Cash Withdrawal ", ConsoleColor.Yellow);
            Console.WriteLine("1. RM100 \t 5.RM1000");
            Console.WriteLine("2. RM200 \t 6.RM2000 ");
            Console.WriteLine("3. RM300 \t 7.RM5000 ");
            Console.WriteLine("4. RM500 \t 8. Back ");
            Console.Write("Enter Your Option:");
        }
        public static void Login_Attempt(User p)
        {
            p.Login_Attempt--;
            if (p.Login_Attempt == 0)
            {
                Console.WriteLine($"\nInvalid Card No or Pin No.");
                color_text("Login failure, Your account has been locked. ", ConsoleColor.Red);
            }
            else
            {
                Console.WriteLine($"\nInvalid Card No or Pin No.");
                color_text($"Login unsuccessful, attempt available: {p.Login_Attempt}", ConsoleColor.Red);
            }
        }
        public static void Count_Notes(int amount)
        {
            int[] notes = { 100, 50, 20, 10 };
            int[] how_many = new int[4];

            for (int i = 0; i < 4; i++)
            {
                if (amount >= notes[i])
                {
                    how_many[i] = amount / notes[i];
                    amount = amount - how_many[i] * notes[i];
                }
            }
            int total = 0;
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("RM" + notes[i] + " x " + how_many[i]);
                total = total + notes[i] * how_many[i];
            }
            Console.WriteLine("Total deposit in (RM) : " + total);
        }
        public static float CalculateMinus_Balance(User p, float num)=> p.balance - num;
        public static float CalculateMinus_WithdrawLimit(User p, float num) => p.withdraw_limit - num;
        public static float CalculatePlus_Balance(User p, float num)=> p.balance + num;
        public static float CalculatePlus_WithdrawLimit(User p, float num)=> p.withdraw_limit + num;
        public static string RandomNumber(int num)
        {
            Random r = new Random();
            string number = "";
            string number1 = "";
            string number2 = "";
            string number3 = "";
            for (int i = 0; i < num; i++)
            {
                number += r.Next(10).ToString();
                number1 += r.Next(10).ToString();
                number2 += r.Next(10).ToString();
                number3 += r.Next(10).ToString();
                Thread.Sleep(1);
            }
            string type = "";
            int random = r.Next(3);
            if (random == 0)
            {
                type = "Master";
            }
            else if (random == 1)
            {
                type = "Visa";
            }
            else 
            {
                type = "Amex";
            }
            number = type + " " + number.Substring(0, 4) + " " + number1.Substring(0, 4) + " " + number2.Substring(0, 4) + " " + number3.Substring(0, 4);
            return number;
        }
        public static string RandomAccountNumber(int num)
        {
            Random r = new Random();
            string number = string.Empty;
            for (int i = 0; i < num; i++)
            {
                number += r.Next(10).ToString();
                Thread.Sleep(1);
            }
            string numbers = "5";
            number = numbers + number.Substring(0, num-1);
            return number;
        }
       
    }
}
