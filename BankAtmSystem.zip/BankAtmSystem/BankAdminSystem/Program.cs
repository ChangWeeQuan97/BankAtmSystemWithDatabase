﻿using BankLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAdminSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> listofcustomer = new List<Customer>();
            Bank bank = new Bank();

            while (true)
            {
                other_method.yellow_head("            Welcome to GE LEGACY BANK     ", ConsoleColor.Yellow);
                Console.WriteLine("\nFor Admin Login Only");
                Console.WriteLine("Username :");
                string username = Console.ReadLine();
                Console.WriteLine("Password :");
                string password = Console.ReadLine();

                if (username != bank.BankAdminName || password != bank.Password)
                {
                    other_method.ColorText("Incorrect Username or Password", ConsoleColor.Red);
                    other_method.PrintforUser();
                }
                else
                {
                    Console.Clear();
                    other_method.ColorText("login Successful", ConsoleColor.Green);
                    while (true)
                    {
                        other_method.yellow_head("            Welcome to GE LEGACY BANK     ", ConsoleColor.Yellow);
                        Console.WriteLine("1. Add Bank Account");
                        Console.WriteLine("2. Manage Bank Account");
                        Console.WriteLine("3. Print the Customer List");
                        Console.WriteLine("4. Logout ");
                        Console.WriteLine("Enter Your Option : ");
                        string opt = Console.ReadLine();
                        Console.Clear();

                        if (opt == "1")
                        {
                            bank.AddAccount(listofcustomer);
                        }
                        else if (opt == "2")
                        {
                            bank.ManageAccount(listofcustomer);
                        }
                        else if (opt == "3")
                        {
                            bank.PrintList(listofcustomer);
                        }
                        else if (opt == "4")
                        {
                            Environment.Exit(0);
                        }
                        else
                        {
                            other_method.color_text("Invalid Option", ConsoleColor.Red);
                        }
                    }
                }
            }
        }
    }
}
