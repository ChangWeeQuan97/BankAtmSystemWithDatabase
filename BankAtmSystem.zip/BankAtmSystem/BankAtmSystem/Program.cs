﻿using BankLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAtmSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            List<User> listofuser = new List<User>()
            {
                new User{Cardno="111",Pinno="123123",Acc_no="111111",Name="qwe"},
                new User{Cardno="222",Pinno="456456",Acc_no="222222",Name="asd"},
                new User{Cardno="333",Pinno="789789",Acc_no="333333",Name="zxc"},
            };
            List<TransactionHistory> transaction = new List<TransactionHistory>();
            float[] Quick_Option = { 100, 200, 300, 500, 1000, 2000, 5000 }; ;

            while (true)
            {
                other_method.yellow_head("       Welcome to GE LEGACY BANK ATM SERVICE ", ConsoleColor.Yellow);
                Console.WriteLine("Enter Your Card No: ");
                string cardno = Console.ReadLine();
                User user = listofuser.SingleOrDefault(x => x.Cardno == cardno);
                
                if (user == null)
                {
                    other_method.color_text("\nThis account doesn't exist", ConsoleColor.Blue);
                }
                else
                {
                    if (user.Login_Attempt <= 0)
                    {
                        other_method.color_text("\nThis Account is locked.", ConsoleColor.Red);
                    }
                    else
                    {
                        Console.WriteLine("Enter Your Pin No: ");
                        string pinno = Console.ReadLine();

                        if (user.Cardno== cardno && user.Pinno == pinno)
                        {
                            user.Login_Successful();

                            while (true)
                            {
                                user.Menu();
                                string menu = Console.ReadLine();
                                Console.Clear();

                                if (menu == "1")
                                {
                                    user.cek_Balance();
                                }
                                else if (menu == "2")
                                {
                                    while (true)
                                    {
                                        other_method.yellow_text("                Withdrawal ", "\nPlease enter the Withdrawal Amount: \t  Back (press 1 to back) ");
                                        user.cek = float.TryParse(Console.ReadLine(), out float withdraw);

                                        if (user.cek == false)
                                        {
                                            other_method.color_text("\nEnter Numbers Only.", ConsoleColor.Blue);
                                        }
                                        else
                                        {
                                            if (withdraw > user.balance)
                                            {
                                                user.Insufficient_Balance();
                                                break;
                                            }
                                            else
                                            {
                                                if (withdraw > user.withdraw_limit)
                                                {
                                                    user.Require_Balance("withdraw", withdraw);
                                                    break;
                                                }
                                                else
                                                {
                                                    if (withdraw == 1)
                                                    {
                                                        Console.Clear();
                                                        break;
                                                    }
                                                    else if (withdraw < 1)
                                                    {
                                                        other_method.color_text("\nCan't insert negative number. ", ConsoleColor.Red);
                                                    }
                                                    else
                                                    {
                                                        if (withdraw % 10 != 0)
                                                        {
                                                            other_method.Min_amount();
                                                        }
                                                        else
                                                        {
                                                            other_method.yes_no("\nDo you want to continue? ");
                                                            if (Console.ReadLine() == "1")
                                                            {
                                                                user.Balance_After_Withdraw(withdraw,transaction);

                                                                if (Console.ReadLine() == "1")
                                                                {
                                                                    other_method.Print_Receipt();
                                                                    continue;
                                                                }
                                                                Console.Clear();
                                                                break;
                                                            }
                                                            Console.Clear();
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (menu == "3")
                                {
                                    while (true)
                                    {
                                        other_method.Fast_Cash();
                                        string FastWithdraw = Console.ReadLine();
                                        Console.Clear();

                                        if (FastWithdraw == "1")
                                        {
                                            user.fastwithdraw(Quick_Option[0], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "2")
                                        {
                                            user.fastwithdraw(Quick_Option[1], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "3")
                                        {
                                            user.fastwithdraw(Quick_Option[2], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "4")
                                        {
                                            user.fastwithdraw(Quick_Option[3], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "5")
                                        {
                                            user.fastwithdraw(Quick_Option[4], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "6")
                                        {
                                            user.fastwithdraw(Quick_Option[5], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "7")
                                        {
                                            user.fastwithdraw(Quick_Option[6], transaction);
                                            break;
                                        }
                                        else if (FastWithdraw == "8")
                                        {
                                            Console.Clear();
                                            break;
                                        }
                                        else
                                        {
                                            other_method.color_text("Invalid Option", ConsoleColor.Red);
                                        }
                                    }
                                }
                                else if (menu == "4")
                                {
                                    while (true)
                                    {
                                        other_method.yellow_text("                Deposit ", "\nPlease enter the Deposit Amount: \t  Back (press 1 to back)");
                                        user.cek = int.TryParse(Console.ReadLine(), out int deposit);

                                        if (user.cek == false)
                                        {
                                            other_method.color_text("\nEnter Numbers Only.", ConsoleColor.Blue);
                                        }
                                        else
                                        {
                                            if (deposit == 1)
                                            {
                                                Console.Clear();
                                                break;
                                            }
                                            else if (deposit < 1)
                                            {
                                                other_method.color_text("\nCan't insert negative number. ", ConsoleColor.Red);
                                            }
                                            else
                                            {
                                                if (deposit % 10 != 0)
                                                {
                                                    other_method.Min_amount();
                                                }
                                                else
                                                {
                                                    other_method.yes_no("\nDo you want to continue? ");
                                                    if (Console.ReadLine() == "1")
                                                    {
                                                        user.Balance_After_Deposit(deposit, transaction);

                                                        if (Console.ReadLine() == "1")
                                                        {
                                                            other_method.Print_Receipt();
                                                            continue;
                                                        }
                                                        Console.Clear();
                                                        break;
                                                    }
                                                    Console.Clear();
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (menu == "5")
                                {
                                    while (true)
                                    {
                                        other_method.yellow_text("              Renew Pin No ", "\nEnter Your old Pin No: \t  Back (press 1 to back)");
                                        string currentpin = Console.ReadLine();
                                        user.cek = int.TryParse(currentpin, out int current_pin);

                                        if (user.cek == false)
                                        {
                                            other_method.color_text("\nEnter Numbers Only.", ConsoleColor.Blue);
                                        }
                                        else if (current_pin == 1)
                                        {
                                            Console.Clear();
                                            break;
                                        }
                                        else
                                        {
                                            if (currentpin != user.Pinno)
                                            {
                                                other_method.color_text("\nIncorrect Pin No", ConsoleColor.Red);
                                            }
                                            else
                                            {
                                                user.Enter_New_Pin();
                                                break;
                                            }
                                        }
                                    }
                                }
                                else if (menu == "6")
                                {
                                    while (true)
                                    {
                                        other_method.yellow_text("           Third Party Transfer ", "\nEnter the account number that you want to transfer : \t  Back (press 1 to back)");
                                        string accno = Console.ReadLine();

                                        if (accno == "1")
                                        {
                                            Console.Clear();
                                            break;
                                        }
                                        else if (accno == user.Acc_no)
                                        {
                                            other_method.color_text("\nCan't transfer to your own account. ", ConsoleColor.Red);
                                        }
                                        else
                                        {
                                            User transfer_other = listofuser.SingleOrDefault(x => x.Acc_no == accno);
                                            if (transfer_other==null)
                                            {
                                                other_method.color_text("\nThis account doesn't exist", ConsoleColor.Blue);
                                            }
                                            else
                                            {
                                                Console.WriteLine("\nEnter the amount: ");
                                                user.cek = float.TryParse(Console.ReadLine(), out float transfer);

                                                if (user.cek == false)
                                                {
                                                    other_method.color_text("\nEnter Numbers Only.", ConsoleColor.Blue);
                                                }
                                                else
                                                {
                                                    if (transfer > user.balance)
                                                    {
                                                        user.Insufficient_Balance();
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        if (transfer > user.withdraw_limit)
                                                        {
                                                            user.Require_Balance("transfer", transfer);
                                                            break;
                                                        }
                                                        else
                                                        {
                                                            if (transfer <= 0)
                                                            {
                                                                other_method.color_text("\nCan't insert negative number. ", ConsoleColor.Red);
                                                            }
                                                            else
                                                            {
                                                                other_method.yes_no("\nDo you want to continue? ");
                                                                if (Console.ReadLine() == "1")
                                                                {
                                                                    user.Balance_After_Transfer(transfer_other, transfer, transaction);
                                                                   
                                                                    if (Console.ReadLine() == "1")
                                                                    {
                                                                        other_method.Print_Receipt();
                                                                        continue;
                                                                    }
                                                                    Console.Clear();
                                                                    break;
                                                                }
                                                                Console.Clear();
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (menu == "7")
                                {
                                    other_method.yellow_head("                 Transaction History ", ConsoleColor.Yellow);
                                    if (transaction.Count == 0)
                                    {
                                        other_method.color_text("\nNo record", ConsoleColor.Blue);
                                        continue;
                                    }
                                    user.table(transaction.OrderByDescending(x=>x.TransactionTime));
                                }
                                else if (menu == "8")
                                {
                                    user.Account_Detail_Table();
                                }
                                else if (menu == "9")
                                {
                                    other_method.Thank_you();
                                    break;
                                }
                                else if (menu == "10")
                                {
                                    Environment.Exit(0);
                                }
                                else
                                {
                                    other_method.color_text("Invalid Option", ConsoleColor.Red);
                                }
                            }
                        }
                        else
                        {
                            other_method.Login_Attempt(user);
                        }
                    }
                }
            }
        }
    }
}
